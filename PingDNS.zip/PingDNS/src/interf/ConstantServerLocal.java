package interf;

public class ConstantServerLocal {
	
	public static final String SERVER_ID = "Server";
	public static final int Server_PORT = 1099;

}
