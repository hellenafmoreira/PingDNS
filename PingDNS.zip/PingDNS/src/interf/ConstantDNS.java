package interf;

public class ConstantDNS {
	
	public static final String DNS_ID = "DNS";
	public static final int DNS_PORT = 1100;

}